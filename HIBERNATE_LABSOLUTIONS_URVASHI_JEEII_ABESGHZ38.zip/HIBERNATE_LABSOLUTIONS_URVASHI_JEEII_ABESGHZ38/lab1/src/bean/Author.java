package bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Author {
	@Id
	@Column(name="AuthorID")
	private int id;
	@Column(name="FirstName")
	private String fname;
	@Column(name="MiddleName")
	private String mname;
	@Column(name="LastName")
	private String lname;
	@Column(name="ContactNo")
	private int num;
	
	public Author() {
		
	}
	public Author(int id, String fname, String mname, String lname, int num) {
		super();
		this.id = id;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.num = num;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	
	}
