package bean;

import java.util.List;

import dao.AuthorDao;

public class AuthorMain {

	public static void main(String[] args) {
		AuthorDao ad = new AuthorDao();
		ad.createAuthor(new Author(101, "Fuzail", "Ahmad", "Nasiri", 9876543));
		ad.createAuthor(new Author(102, "Shri", "Munshi", "Premchand", 92874637));
		ad.createAuthor(new Author(103, "Ramdhari", "Singh", "Dinkar", 92874437));
		ad.createAuthor(new Author(104, "Shri", "Munshi", "Premchand", 92874637));
		System.out.println("Authors saved!!!!!!");
		System.out.println("before deletion");
		List<Author> li = ad.getAllAuthor();
		for (Author au : li) {
			System.out.println(au.getId() + "\t" + au.getFname() + "\t" + au.getMname() + "\t" + au.getLname() + "\t"
					+ au.getNum());
		}

		String s = ad.deleteAuthor(102);
		System.out.println(s);
		System.out.println("after deletion");
		List<Author> li1 = ad.getAllAuthor();
		for (Author au : li1) {
			System.out.println(au.getId() + "\t" + au.getFname() + "\t" + au.getMname() + "\t" + au.getLname() + "\t"
					+ au.getNum());
		}
		String s1 = ad.updateAuthor(104, "Mr.", "Munshi", "Premchand", 92874637);
		System.out.println(s1);
		System.out.println("after updation");
		List<Author> li2 = ad.getAllAuthor();
		for (Author au : li2) {
			System.out.println(au.getId() + "\t" + au.getFname() + "\t" + au.getMname() + "\t" + au.getLname() + "\t"
					+ au.getNum());
		}

	}
}