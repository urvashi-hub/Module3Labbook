package dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import bean.Author;
import config.MyFactory;

public class AuthorDao {
	EntityManager em = MyFactory.getEntityManager();
	public void createAuthor(Author au) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(au);
		tx.commit();
	}
	
	public String deleteAuthor(int id) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Author au = em.find(Author.class, id);
		em.remove(au);
		tx.commit();
		return "Student deleted!!!!!!";
	}
	
	public String updateAuthor(int id, String fname, String mname, String lname, int num) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Author au = em.find(Author.class, id);
		if (au != null) {
			au.setId(id);
			au.setFname(fname);
			au.setMname(mname);
			au.setLname(lname);
			au.setNum(num);
			em.persist(au);
			tx.commit();
			return "Author updated!!!!!!";
		} else {
			return "Author not available!!!";
		}

	}
	public Author getAuthor(int id) {
		Author au = em.find(Author.class, id);
		return au;
	}
	public List<Author> getAllAuthor() {
		@SuppressWarnings("unchecked")
		List<Author> li = em.createQuery("from Author au").getResultList();
		return li;
	}

}
