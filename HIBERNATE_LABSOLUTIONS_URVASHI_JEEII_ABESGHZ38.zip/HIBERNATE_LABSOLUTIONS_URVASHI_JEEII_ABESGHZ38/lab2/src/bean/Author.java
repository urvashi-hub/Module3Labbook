package bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Author2")
public class Author {
	@Id
	@Column(name = "ID")
	private int aid;
	private String name;
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Book> book;

	public Author() {

	}

	public Author(int aid, String name) {
		super();
		this.aid = aid;
		this.name = name;
	}

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Book> getBook() {
		return book;
	}

	public void setBook(List<Book> book) {
		this.book = book;
	}

}
